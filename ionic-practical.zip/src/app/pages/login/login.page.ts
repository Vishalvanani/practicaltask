import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  loginForm: FormGroup;
  constructor(private formBuilder: FormBuilder, private router: Router, private commonService: CommonService) {}

  //
  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required]],
    });
  }

  // --- Handle Login
  login() {
    console.log(this.loginForm.value);
    // check validation for login
    if (
      this.loginForm.value.email.toLowerCase() == 'test@test.com' &&
      this.loginForm.value.password == '8256455'
    ) {
      // Redirect home page if login success
      this.router.navigateByUrl('/home');
    } else {
      // Show error message if login failed
      this.commonService.presentAlert('Wrong email or password.');
    }
  }
}
