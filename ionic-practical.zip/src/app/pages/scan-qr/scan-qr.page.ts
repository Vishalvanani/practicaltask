import { Component, OnInit } from '@angular/core';
import { BarcodeScanner } from '@capacitor-community/barcode-scanner';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-scan-qr',
  templateUrl: './scan-qr.page.html',
  styleUrls: ['./scan-qr.page.scss'],
})
export class ScanQrPage implements OnInit {
  isScannerRunning: boolean = false;
  qrCodeB64: string = '';
  qrCodeStr: string = '';

  constructor(private commonService: CommonService) {}

  ngOnInit() {}

  // --- Start QR code scanner
  async startScanner() {
    // Check camera permission
    let status = await BarcodeScanner.checkPermission({ force: true });
    console.log('status: ', status);

    document.querySelector('body')?.classList.add('scanner-active');

    document.body.style.background = 'transparent';

    // make background of WebView transparent
    await BarcodeScanner.hideBackground();

    await BarcodeScanner.toggleTorch();
    this.isScannerRunning = true;
    await BarcodeScanner.startScanning(
      {
        targetedFormats: ['QR_CODE'],
      },
      (result, err) => {
        console.log('result: ', result);
        console.log('err: ', err);
        // if the result has content
        document.querySelector('body')?.classList.remove('scanner-active');
        this.isScannerRunning = false;
        if (result.hasContent) {
          console.log(result.content); // log the raw scanned content
          this.qrCodeStr = result.content;
          this.qrCodeB64 = this.commonService.toQRCode(result.content, 350);
        }
      }
    ); // start scanning and wait for a result
  }

  // --- stop scanning when navigate from page
  async ngOnDestroy() {
    await BarcodeScanner.stopScan();
  }
}
