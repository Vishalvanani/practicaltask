import { Injectable } from '@angular/core';
import { AlertController } from '@ionic/angular';
declare var QRious: any

@Injectable({
  providedIn: 'root',
})
export class CommonService {
  constructor(private alertCtrl: AlertController) {}

  // --- Generate random string with given length
  generateRandomString(length: number) {
    let result = '';
    const characters =
      'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const charactersLength = characters.length;
    let counter = 0;
    while (counter < length) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
      counter += 1;
    }
    return result;
  }

  // --- generate qr code
  toQRCode(code: string, size: number): string {
    // set QR code
    var qr = new QRious({
      value: code,
      size: size,
    });

    var qrBase64 = qr.toDataURL();

    return qrBase64;
  }

  // --- Present alert
  alert: any;
  presentAlert(msg: any, title?: any, buttons?: any, cssClass?: any) {
    return new Promise(async (resolve, reject) => {
      this.alert = await this.alertCtrl.create({
        header: title ? title : 'Alert',
        message: msg,
        backdropDismiss: false,
        buttons: buttons
          ? buttons
          : [
              {
                text: 'Cancel',
                role: 'cancel',
                handler: () => {
                  resolve('');
                },
              },
            ],
      });
      this.alert.present();
      return alert;
    });
  }
}
